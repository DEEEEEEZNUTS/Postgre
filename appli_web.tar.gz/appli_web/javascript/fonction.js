/*
 *Cela va te permettre d'uniformiser les fonctions 'getElementById', 'getElementsByName' et 'getElementByTagName'
 * pour IE et FF (et d'autres navigateur mais ce sont les principaux) 
 */
if(!document.getElementById) document.getElementById=function (id) {
    return eval("document.all."+id);
}

if(!document.getElementsByName) document.getElementsByName=function (name) {
    var el=document.all,result=new Array(),j=0;
    for(var i=0;i<el.length;i++) if(el[i].name.toLowerCase()==name.toLowerCase()) result[j++]=el[i];
    return result;
 }

if(!document.getElementsByTagName) document.getElementsByTagName=function (tagName) {
    var el=document.all,result=new Array(),j=0;
    for(var i=0;i<el.length;i++) if(el[i].tagName.toLowerCase()==tagName.toLowerCase()) result[j++]=el[i];
    return result;
}


//pour que ie comprenne les getelementByName
function getElementsByName_iefix(tag, name) {

         var elem = document.getElementsByTagName(tag);
         var arr = new Array();
         for(i = 0,iarr = 0; i < elem.length; i++) {
                  att = elem[i].getAttribute("name");
                  if(att == name) {
                           arr[iarr] = elem[i];
                           iarr++;
                  }
         }
         return arr;
}


function getSelectedRadioValue (radiobutton){
    var returnValue = "";
    if (document.getElementsByName(radiobutton).length == 1){
            returnValue = document.getElementsByName(radiobutton).value;
    } else {
        for (i=0;i<document.getElementsByName(radiobutton).length;i++){
            if (document.getElementsByName(radiobutton)[i].checked==true) {
                returnValue=document.getElementsByName(radiobutton)[i].value;
            }
        }
    }

    return returnValue;
}


//Mettre tout en majuscule
function majuscule(champ) 
{
    var m=champ.value;
    m = m.toUpperCase();
    champ.value = m;
    AfficheMail()
}

//Mettre la premiere lettre en majuscule et le reste en minuscule
function nompropre(champ) 
{
    var m=champ.value;
    m = m.charAt(0).toUpperCase() + m.substring(1).toLowerCase();
    champ.value = m;
    AfficheMail()
}

function envoieRequete(url,id)
{
         var xhr_object = null;
         var position = id;
          if(window.XMLHttpRequest) xhr_object = new XMLHttpRequest();
          else
         if (window.ActiveXObject) xhr_object = new ActiveXObject("Microsoft.XMLHTTP");
  
         // On ouvre la requete vers la page d�sir�e
         xhr_object.open("GET", url, true);
         xhr_object.onreadystatechange = function(){
         if ( xhr_object.readyState == 4 )
         {
                // j'affiche dans la DIV sp�cifi�es le contenu retourn� par le fichier
                 document.getElementById(position).innerHTML = xhr_object.responseText;                
         }
        }
         // dans le cas du get
   xhr_object.send(null);
 
 }

function envoieRequete2(url, params)
{
     var xhr_object = null;
     if(window.XMLHttpRequest) { // FIREFOX
          xhr_object = new XMLHttpRequest();
     } else {
         if(window.ActiveXObject) { // IE
            xhr_object = new ActiveXObject("Microsoft.XMLHTTP");
         } else {
            return(false);
         }
     }

     //ajout de la liste des params en GET
     /*if(params!="") { url = url + "?" + params; }*/

     xhr_object.open("POST", url, false);
     //changer le type MIME de la requête pour envoyer des données avec la méthode POST ,  !!!! cette ligne doit etre absolument apres http_request.open('POST'....
     xhr_object.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

     // ici tu peux rajouter les autres valeurs que tu as passees en arguments lors de l'appel de la fonction
     //xhr_object.send(null); //method GET
     xhr_object.send(params); //method POST


     if(xhr_object.readyState == 4) { 
         var reponse = xhr_object.responseText;
         //reponse.replace(/ /g, '');
         return(reponse);
     } else {
         return(false);
     }
}


function recupChiffres(s) {
        var n = [];
	s = s.split(/[^0-9]+/);
	for(var i=0; i<s.length; i++) {
            if(s[i].match(/[0-9]+/)) {
                n.push(s[i]);
            }
        }
	return n;
}

 function FormatStr(Str){
     StrNewStr="";
     for(i=0;i<=Str.length;i++){
         StrChar=Str.substring(i,i+1);
         if(StrChar!=" " || Str.substring(i-1,i)!=" "){
            StrNewStr=StrNewStr+StrChar;
         }
     }
     return StrNewStr;
 } 