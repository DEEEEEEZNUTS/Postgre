﻿
	<ul id="menu">
		<li id="tabnav" <?php if (strpos($_SERVER['REQUEST_URI'],'liste/index.php')>0) {echo 'class="active"';} ?>><a href="../liste/index.php">PC du parc</a></li>
		<li id="tabnav" <?php if (strpos($_SERVER['REQUEST_URI'],'detail/index.php')>0) {echo 'class="active"';} ?>><a href="../detail/index.php">Détail / Ajout PC</a></li>
	</ul>


			<input type="checkbox" id="nav-trigger" class="nav-trigger" />
			<label for="nav-trigger"></label>
