﻿<?php 
	include '../include/header.php'; 
	include '../include/menu.php';
?>
<div class="site-wrap"> 

<?php include 'cable.php'; ?>
</div>
<?php 
	include '../include/footer.php'; 
?>