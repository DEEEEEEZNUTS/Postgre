<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>
	<link type="image/x-icon" rel="shortcut icon" href="../images/favicon.ico" />

	<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
	<meta http-equiv="Content-Style-Type" content="text/css" />
	<meta http-equiv="Pragma" content="no-cache" />
	<link rel="stylesheet" type="text/css" href="../css/style.css" />
	<link rel="stylesheet" type="text/css" href="../css/pager.css" />
	<link rel="stylesheet" type="text/css" href="../css/form.css" />
	<link rel="stylesheet" type="text/css" href="../css/columns.css" />
	<link rel="stylesheet" type="text/css" href="../css/date_input.css" />
	<link rel="stylesheet" type="text/css" href="../css/tabs-no-images.css" />
	<!-- CSS spécifiques aux pages -->
        <link rel="stylesheet" type="text/css" href="../css/style_liste.css" />


	<script type="text/javascript" src="../javascript/jquery.tools.min.js"></script>
	<script type="text/javascript" src="../javascript/jquery.tablesorter.js"></script>
	<script type="text/javascript" src="../javascript/jquery.tablesorter.pager.js"></script>
	<script type="text/javascript" src="../javascript/fonction.js"></script>
</head>
<body>
<?php
//include "../include/bdd.php";
include "../include/services.php";
?>
