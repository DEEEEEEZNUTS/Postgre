<?php
/* affichage du contenu de l'onglet correspondant au type de pc vu ou modifié précédemment */
if (!isset($_GET['type_pc']) || $_GET['type_pc']=="") {
    $_GET['type_pc'] = "Fixe";
}

/**
 * action duplication d'une ligne
 *
 */
if(isset($_GET['action']) && $_GET['action']=="delete") {
    if (isset($_GET['idpc']) && $_GET['idpc']!="" && is_numeric($_GET['idpc']) && $_GET['idpc']>0 ) {

        //1. recherche si l'id du modèle existe
        $requete = "DELETE FROM `ordinateur` WHERE `id`=".$_GET['idpc'];

        $requete_prepare = $bdd->prepare($requete);
        try{
            $requete_prepare->execute();
        }
        catch(PDOException $e){
            print($e->getMessage());
        }

    }
}

?>
<script>
$(function() {
		$("#triFixe")
			.tablesorter({widthFixed: true, widgets: ['zebra']})
			.tablesorterPager({container: $(".pager")});

        $("#triPortable")
		.tablesorter({widthFixed: true, widgets: ['zebra']})
		.tablesorterPager({container: $(".pager")});




                /* toutes les listes sont cachées par défaut, on affiche la liste des pc fixes par défaut */
                //$("#liste_Fixe").removeClass("hidden_listepc").addClass("show_listepc");

                /* forcer la pagination à la mettre sous le tableau */
                $(".pager").css({'position':'relative'});
                $(".pager").css({'background':'none'});
});

function show_tab(id_tab) {
    switch(id_tab)
    {


        case 'Portable':
        /* coloration onglet actif */
        $(".tabs_list li").removeClass("active");
        $("#li_"+id_tab).addClass("active");
        /* on cache tout le contenu des onglets */
        $(".listepc").removeClass("show_listepc").addClass("hidden_listepc");
        /* on montre le contenu de l'onglet souhaité */
        $("#liste_"+id_tab).removeClass("hidden_listepc").addClass("show_listepc");
        break;

        default: /* fixe par defaut */
        /* coloration onglet actif */
        $(".tabs_list li").removeClass("active");
        $("#li_"+id_tab).addClass("active");
        /* on cache tout le contenu des onglets */
        $(".listepc").removeClass("show_listepc").addClass("hidden_listepc");
        /* on montre le contenu de l'onglet souhaité */
        $("#liste_"+id_tab).removeClass("hidden_listepc").addClass("show_listepc");

    }
}

</script>


<!-- onglets des listes -->
<ul class="tabs_list">
    <li id="li_Fixe" class="<?php echo (isset($_GET['type_pc']) && $_GET['type_pc']=="Fixe")?"active":"";?>""><a href="index.php?type_pc=Fixe">Fixe</a></li>
    <li id="li_Portable" class="<?php echo (isset($_GET['type_pc']) && $_GET['type_pc']=="Portable")?"active":"";?>"><a href="index.php?type_pc=Portable">Portable</a></li>

</ul>

<!-- liste des pc fixe -->
<div id="liste_Fixe" class="listepc <?php echo (isset($_GET['type_pc']) && $_GET['type_pc']=="Fixe")?"show_listepc" : "hidden_listepc"; ?>">
    <table class="tablesorter" id="triFixe">
	<thead>
		<tr>
			<th class="headerAction">Actions</th>
			<th width="8%">Numéro</th>
			<th width="10%">Marque/Modèle</th>
			<th width="10%">N° de série</th>
			<th width="10%">Caractéristique</th>
			<th width="10%">Ecran1</th>
			<th width="10%">Ecran2</th>
			<th width="10%">Client</th>
			<th width="10%">Nom</th>
			<th width="8%">Prénom</th>
			<th width="10%">Date emprunt</th>
		</tr>

	</thead>
	<tbody>
    <?php
            //Selection des ecrans disponibles ou celui associé à un PC(type_pc = Fixe)
            $q_liste = "SELECT id, type_pc, numero, marque, caracteristique, client, nom, prenom, ecran1, ecran2, date_emprunt,date_retour, num_serie FROM v_liste_pc ";
            //clause where
            $q_liste .= " WHERE pc_hs = 0 AND obsolete = 0 AND type_pc LIKE '%Fixe%' ";
            //clause order
            $q_liste .= " ORDER BY numero";

            $query_liste = $bdd->prepare($q_liste);

            try{
                    $query_liste->execute();
            }
            catch(PDOException $e){
                    die($e-> getMessage()) ;
            }

            $r_liste = $query_liste->fetchAll();

            foreach($r_liste as $ligne)
            {
                    $cv_date_emprunt = "";
                    $style = '';
                    $styleb = 'style="text-align:center;"';
                    if (!is_null($ligne['date_emprunt'])&&is_null($ligne['date_retour'])) {
                                    $cv_date_emprunt = date("Y/m/d", $ligne['date_emprunt']);
                                    $style  = 'style="background-color: #5291fd;"';
                                    $styleb = 'style="text-align:center;background-color: #5291fd;"';
                    }

                    //couleur
                    echo '<tr>';
                    echo '<td class="tdAct" '.$style.' wrap>'
                    .'<a href="javascript:supprimer(\''.$ligne['id'].'\', \''.$ligne['type_pc'].'\');" title=\'Action supression\'>'.'<img src="../images/supprimer.png" width="18"  title="Supprimer ce modèle" />'.'</a>'
                    .'<a href="javascript:dupliquer(\''.$ligne['id'].'\', \''.$ligne['type_pc'].'\');" title=\'Action duplication\'>'.'<img src="../images/dupliquer.png" width="20"  title="Dupliquer ce modèle" />'.'</a>'
                    .'<a href="javascript:modifier(\''.$ligne['id'].'\', \''.$ligne['type_pc'].'\');" title=\'Action modification\'>'.'<img src="../images/modifier.png" width="20"  title="Modifier ce modèle" />'.'</a>'

                    .'</td>';
                    echo '<td '.$styleb.'>'.$ligne['numero'].'</td>';
                    echo '<td '.$style.'>'.$ligne['marque'].'</td>';
					echo '<td '.$style.'>'.$ligne['num_serie'].'</td>';
                    echo '<td '.$style.'>'.$ligne['caracteristique'].'</td>';
                    echo '<td '.$style.'>'.$ligne['ecran1'].'</td>';
					echo '<td '.$style.'>'.$ligne['ecran2'].'</td>';
                    echo '<td '.$styleb.'>'.$ligne['client'].'</td>';
                    echo '<td '.$styleb.'>'.$ligne['nom'].'</td>';
                    echo '<td '.$styleb.'>'.$ligne['prenom'].'</td>';
                    echo '<td '.$styleb.'>'.$cv_date_emprunt.'</td>';
                    echo '</tr>';
            }

    ?>
            </tbody>
    </table>
    <table style="float:left;"><tr><td>
    <div id="pagerFixe" class="pager" >
            <form>
                    <img src="../images/first.png" class="first"/>
                    <img src="../images/prev.png" class="prev"/>
                    <input type="text" disabled="disabled" class="pagedisplay" />
                    <img src="../images/next.png" class="next"/>
                    <img src="../images/last.png" class="last"/>
                    <input type="hidden" id="pagesize" name="pagesize" class="pagesize" value="1500"/>
            </form>
    </div>
    </td></tr></table>

    <div class="clear"></div>
</div>

<!-- liste des pc portable -->
<div id="liste_Portable" class="listepc <?php echo (isset($_GET['type_pc']) && $_GET['type_pc']=="Portable")?"show_listepc" : "hidden_listepc"; ?>">
    <table class="tablesorter" id="triPortable">
	<thead>
		<tr>
			<th class="headerAction">Actions</th>
			<th width="8%">Numéro</th>
			<th>Marque/Modèle</th>
			<th>N° de série</th>
			<th>Caractéristique</th>
			<th>Ecran1</th>
			<th>Client</th>
			<th>Nom</th>
			<th width="8%">Prénom</th>
			<th>Date emprunt</th>
		</tr>

	</thead>
	<tbody>
    <?php
            //Selection des ecrans disponibles ou celui associé à un PC (type = Portable)
            $q_liste = "SELECT id, type_pc, numero, marque, caracteristique, client, nom, prenom, ecran1, ecran2, date_emprunt,date_retour, num_serie FROM v_liste_pc ";
            //clause where
            $q_liste .= " WHERE pc_hs = 0 AND obsolete = 0 AND type_pc LIKE '%Portable%' ";
            //clause order
            $q_liste .= " ORDER BY numero";

            $query_liste = $bdd->prepare($q_liste);

            try{
                    $query_liste->execute();
            }
            catch(PDOException $e){
                    die($e-> getMessage()) ;
            }

            $r_liste = $query_liste->fetchAll();

            foreach($r_liste as $ligne)
            {
                    $cv_date_emprunt = "";
                    $style = '';
                    $styleb = 'style="text-align:center;"';
                    if (!is_null($ligne['date_emprunt'])&&is_null($ligne['date_retour'])) {
                                    $cv_date_emprunt = date("Y/m/d", $ligne['date_emprunt']);
                                    $style  = 'style="background-color: #5291fd;"';
                                    $styleb = 'style="text-align:center;background-color: #5291fd;"';
                    }

                    //cc
                    echo '<tr>';
                    echo '<td class="tdAct" '.$style.' nowrap>'
                    .'<a href="javascript:supprimer(\''.$ligne['id'].'\', \''.$ligne['type_pc'].'\');" title=\'Action supression\'>'.'<img src="../images/supprimer.png" width="18"  title="Supprimer ce modèle" />'.'</a>'
                    .'<a href="javascript:dupliquer(\''.$ligne['id'].'\', \''.$ligne['type_pc'].'\');" title=\'Action duplication\'>'.'<img src="../images/dupliquer.png" width="20"  title="Dupliquer ce modèle" />'.'</a>'
                    .'<a href="javascript:modifier(\''.$ligne['id'].'\', \''.$ligne['type_pc'].'\');" title=\'Action modification\'>'.'<img src="../images/modifier.png" width="20"  title="Modifier ce modèle" />'.'</a>'
                    .'</td>';
                    echo '<td '.$styleb.'>'.$ligne['numero'].'</td>';
                    echo '<td '.$style.'>'.$ligne['marque'].'</td>';
					echo '<td '.$style.'>'.$ligne['num_serie'].'</td>';
                    echo '<td '.$style.'>'.$ligne['caracteristique'].'</td>';
                    echo '<td '.$style.'>'.$ligne['ecran1'].'</td>';
                    echo '<td '.$styleb.'>'.$ligne['client'].'</td>';
                    echo '<td '.$styleb.'>'.$ligne['nom'].'</td>';
                    echo '<td '.$styleb.'>'.$ligne['prenom'].'</td>';
                    echo '<td '.$styleb.'>'.$cv_date_emprunt.'</td>';
                    echo '</tr>';
            }
    ?>
            </tbody>
    </table>
    <table style="float:left;"><tr><td>
    <div id="pagerPortable" class="pager" >
            <form>
                    <img src="../images/first.png" class="first"/>
                    <img src="../images/prev.png" class="prev"/>
                    <input type="text" disabled="disabled" class="pagedisplay" />
                    <img src="../images/next.png" class="next"/>
                    <img src="../images/last.png" class="last"/>
                    <input type="hidden" id="pagesize" name="pagesize" class="pagesize" value="1500"/>
            </form>
    </div>
    </td></tr></table>

    <div class="clear"></div>
</div>



<script>
    $(function() {
            $("a.wajax").tabs("div.css-panes > div.pane", {effect: 'ajax'});
    });

    /* fonction pour aller à la fiche du modèle à modifier sans confirmation */
    function modifier(idpc,typepc_encours) {
        if(idpc != "") {
            document.location.href = '../detail/index.php?action=modify&idpc=' + idpc + '&type_pc=' + typepc_encours;
            return true;
        } else {
            /*return false;*/
        }
    }

    /* fonction pour confirmer la suppression du modèle choisi */
    function dupliquer(idpc,typepc_encours) {
        if(confirm('Voulez-vous vraiment dupliquer ce modèle ?')) {
            document.location.href = '../detail/index.php?action=duplicate&idpc=' + idpc + '&type_pc=' + typepc_encours;
            return true;
        } else {
            /*return false;*/
        }
    }

    /* fonction pour confirmer la duplication du modèle choisi */
    function supprimer(idpc, typepc_encours) {
        if(confirm('Voulez-vous vraiment supprimer ce modèle ?')) {
            document.location.href = 'index.php?action=delete&idpc=' + idpc + '&type_pc=' + typepc_encours;
            return true;
        } else {
            /*return false;*/
        }
    }
</script>
