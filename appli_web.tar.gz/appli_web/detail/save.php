<?php
ini_set('display_errors',1);
include "../include/bdd.php";

if ( isset($_POST["submit"]) && ($_POST["submit"]=="retourliste"||$_POST["submit"]=="Revenir à la liste") ) {

    header('Location: ../liste/index.php?type_pc='.$_POST['typepc']);
}
elseif ( isset($_POST["submit"]) && ($_POST["submit"]=="enregistrer"||$_POST["submit"]=="Enregistrer les informations") ) {
	//On converti la case ghost coch�e en 1 sinon on garde 0

	$ghost = 0;
	if (isset($_POST['ghost'])) {
	if($_POST['ghost']=="on") {
		$ghost = 1;
	}
	}

	$pchs = 0;
	if (isset($_POST['pc_hs'])) {
	if($_POST['pc_hs']=="on") {
		$pchs = 1;
	}
	}

	$pcob = 0;
	if (isset($_POST['pc_ob'])) {
	if($_POST['pc_ob']=="on") {
		$pcob = 1;
	}
	}

	$time_date_achat = mktime(0, 0, 0, 01, 01, 2000);
	if (isset($_POST['date_achat']) && $_POST['date_achat']!="") {
		list($day, $month, $year) = explode('/', $_POST['date_achat']);
		$time_date_achat = mktime(0, 0, 0, $month, $day, $year);
	}

	if ($_POST['pc_id']==0) {
		// Requête concernant un nouveau PC a ins�rer en base
		$requete = "INSERT INTO ordinateur (";
		$requete .= "type_pc,numero, pc_hs, marque, num_serie, cd_pilote, ghost, caracteristique, date_achat, magasin, garantie, commentaires, infos_suppl, id_ecran1, id_ecran2, id_cable, obsolete ";
		$requete .= ") VALUES (";
		$requete .= "'".addslashes($_POST['typepc'])."',";
		$requete .= "'".addslashes($_POST['numero'])."',";
		$requete .= addslashes($pchs).",";
		$requete .= "'".addslashes($_POST['marque'])."',";
		$requete .= "'".addslashes($_POST['numserie'])."',";
		$requete .= "'".addslashes($_POST['cdpilote'])."',";
		$requete .= addslashes($ghost).",";
		$requete .= "'".addslashes($_POST['caracteristique'])."',";
		$requete .= addslashes($time_date_achat).",";
		$requete .= "'".addslashes($_POST['magasin'])."',";
		$requete .= addslashes($_POST['garantie']).",";
		$requete .= "'".addslashes($_POST['commentaires'])."',";
		$requete .= "'".addslashes($_POST['infos_suppl'])."',";
		$requete .= addslashes($_POST['ecran1']).",";
		$requete .= addslashes($_POST['ecran2']).",";
		$requete .= addslashes($_POST['cable']).",";
		$requete .= $pcob;
		$requete .= ")";

		$query_ordinateur = $bdd->prepare($requete);
		$query_ordinateur->execute();

		$sauve_id_pc = $bdd->lastInsertId();
	}
	else {
			// Si on utilise INTERNET EXPLORER
		if (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== FALSE || strpos($_SERVER['HTTP_USER_AGENT'], 'Trident') !== FALSE) {

			$requete  = "UPDATE ordinateur SET ";
			$requete .= "type_pc = '".addslashes($_POST['typepc'])."',";
			$requete .= "numero = '".addslashes($_POST['numero'])."',";
			$requete .= "pc_hs = ".addslashes($pchs).",";
			$requete .= "marque = '".addslashes($_POST['marque'])."',";
			$requete .= "num_serie = '".addslashes($_POST['numserie'])."',";
			$requete .= "cd_pilote = '".addslashes($_POST['cdpilote'])."',";
			$requete .= "ghost = ".addslashes($ghost).",";
			$requete .= "caracteristique = '".addslashes($_POST['caracteristique'])."',";
			$requete .= "date_achat = ".addslashes($time_date_achat).",";
			$requete .= "magasin = '".addslashes($_POST['magasin'])."',";
			$requete .= "garantie = ".addslashes($_POST['garantie']).",";
			$requete .= "commentaires = '".addslashes($_POST['commentaires'])."',";
			$requete .= "infos_suppl = '".addslashes($_POST['infos_suppl'])."',";
			$requete .= "id_ecran1 = ".addslashes($_POST['ecran1']).",";
			$requete .= "id_ecran2 = ".addslashes($_POST['ecran2']).",";
			$requete .= "id_cable = ".addslashes($_POST['cable']).", ";
			$requete .= "obsolete = ".$pcob." ";
			$requete .= "WHERE id = ".$_POST['pc_id'];
			$query_ordinateur = $bdd->prepare($requete);
			$query_ordinateur->execute();
			$sauve_id_pc = $_POST['pc_id'];
		}
		else {	// Si on utilise GOOGLE CHROME

			$requete  = "UPDATE ordinateur SET ";
			$requete .= "type_pc = '".addslashes($_POST['typepc'])."',";
			$requete .= "numero = '".addslashes($_POST['numero'])."',";
			$requete .= "pc_hs = ".addslashes($pchs).",";
			$requete .= "marque = '".addslashes($_POST['marque'])."',";
			$requete .= "num_serie = '".addslashes($_POST['numserie'])."',";
			$requete .= "cd_pilote = '".addslashes($_POST['cdpilote'])."',";
			$requete .= "ghost = ".addslashes($ghost).",";
			$requete .= "caracteristique = '".addslashes($_POST['caracteristique'])."',";
			$requete .= "date_achat = ".addslashes($time_date_achat).",";
			$requete .= "magasin = '".addslashes($_POST['magasin'])."',";
			$requete .= "garantie = ".addslashes($_POST['garantie']).",";
			$requete .= "commentaires = '".addslashes($_POST['commentaires'])."',";
			$requete .= "infos_suppl = '".addslashes($_POST['infos_suppl'])."',";
			$requete .= "id_ecran1 = ".addslashes($_POST['ecran1']).",";
			$requete .= "id_ecran2 = ".addslashes($_POST['ecran2']).",";
			$requete .= "id_cable = ".addslashes($_POST['cable']).", ";
			$requete .= "obsolete = ".$pcob." ";
			$requete .= "WHERE id = ".$_POST['pc_id'];
			$query_ordinateur = $bdd->prepare($requete);
			$query_ordinateur->execute();
			$sauve_id_pc = $_POST['pc_id'];
		}
	}

	if ($_POST['date_emprunt']<>"" && $_POST['id_sortie']==0) {
		list($day, $month, $year) = explode('/', $_POST['date_emprunt']);
		$time_date_emprunt = mktime(0, 0, 0, $month, $day, $year);

		$requete  = "INSERT INTO sortie (";
		$requete .= "id_ordinateur, client, nom, prenom, ecran1, ecran2, cable, comm_retour, date_emprunt ";
		$requete .= ") VALUES (";
		$requete .= addslashes($sauve_id_pc).",";
		$requete .= "'".addslashes($_POST['client'])."',";
		$requete .= "'".addslashes($_POST['nom'])."',";
		$requete .= "'".addslashes($_POST['prenom'])."',";
		$requete .= addslashes($_POST['ecran1']).",";
		$requete .= addslashes($_POST['ecran2']).",";
		$requete .= addslashes($_POST['cable']).",";
		$requete .= "'".addslashes($_POST['commentaires_retour'])."',";
		$requete .= addslashes($time_date_emprunt);
		$requete .=")";
		echo $requete;
		$query_sortie = $bdd->prepare($requete);
		$query_sortie->execute();
		$sauve_id_sortie = $bdd->lastInsertId();
		$requete = "UPDATE ordinateur SET id_sortie = ".addslashes($sauve_id_sortie)." WHERE id = ".$sauve_id_pc;
		$query_sortie = $bdd->prepare($requete);
		$query_sortie->execute();
	}
	if ($_POST['date_emprunt']<>"" && $_POST['id_sortie']>0) {
		list($day, $month, $year) = explode('/', $_POST['date_emprunt']);
		$time_date_emprunt = mktime(0, 0, 0, $month, $day, $year);
		$requete  = "UPDATE sortie SET ";
		$requete .= "id_ordinateur = ".addslashes($_POST['pc_id']).",";
		$requete .= "client = '".addslashes($_POST['client'])."',";
		$requete .= "nom = '".addslashes($_POST['nom'])."',";
		$requete .= "prenom = '".addslashes($_POST['prenom'])."',";
		$requete .= "ecran1 = ".addslashes($_POST['ecran1']).",";
		$requete .= "ecran2 = ".addslashes($_POST['ecran2']).",";
		$requete .= "cable = ".addslashes($_POST['cable']).",";
		$requete .= "comm_retour = '".addslashes($_POST['commentaires_retour'])."',";
		$requete .= "date_emprunt = ".addslashes($time_date_emprunt);
		$requete .= " WHERE id = ".$_POST['id_sortie'];
		echo $requete;
		$query_sortie = $bdd->prepare($requete);
		$query_sortie->execute();
	}
	 // Si on crée un nouveau PC on renvoie sur la même page grace au dernier id sauvegardé
	 // Si on modifie un pc, on renvoie sur la page de modification grace à l'id du pc
	header('Location: ../detail/index.php?action=modify&idpc='.$sauve_id_pc.'&type_pc='.$_POST['typepc']);

}

else {
		$dateretour = mktime();
		$month = 0;
		$day = 0;
		$year = 0;
		$time_date_emprunt = mktime(0, 0, 0, $month, $day, $year);
		$requete  = "UPDATE sortie SET ";
		$requete .= "date_retour = ".addslashes($dateretour);
		$requete .= " WHERE id = ".$_POST['id_sortie'];
		$query_sortie = $bdd->prepare($requete);
		$query_sortie->execute();
		$requete  = "UPDATE ordinateur SET ";
		$requete .= "id_ecran1 = 0,";
		$requete .= "id_ecran2 = 0,";
		$requete .= "id_cable = 0 ";
		$requete .= " WHERE id = ".$_POST['pc_id'];
		$query_sortie = $bdd->prepare($requete);
		$query_sortie->execute();
		header("Location: index.php?idpc=".$_POST['pc_id']);
	}
?>