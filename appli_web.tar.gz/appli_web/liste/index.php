<?php 
	include '../include/header.php'; 
	include '../include/menu.php';
?>
<div class="site-wrap">    
    <?php include 'liste.php'; ?>
    <div class="clear"></div>

</div>
<?php 
	include '../include/footer.php'; 
?>