<?php
/** Constantes pour la base de donnée. */
DEFINE('SERVEUR_BDD', 'localhost');
DEFINE('NAME_BDD', 'appli_web');
DEFINE('LOGIN_BDD', 'root');
DEFINE('PASS_BDD', 'toor');
?>
