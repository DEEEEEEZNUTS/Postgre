﻿<?php 
header('Location: liste/index.php');	
?>