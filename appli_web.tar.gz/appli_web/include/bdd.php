<?php
include 'constante.php';
/** Connexion à la base de donnée. */
try{
$bdd = new PDO('mysql:host=localhost;dbname=appli_web', 'root','toor');
$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Obligatoire pour la suite
}
catch(PDOException $e)
{
echo "Echec : " . $e->getMessage();
}
?>
