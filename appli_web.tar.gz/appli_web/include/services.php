<?php
/* 
 * Fichiers des services pour les appels Ajax
 */

//fichiers necessaires
include "bdd.php";


/**
 * action recupérer en $_POST : $_POST['actionServices']
 */


/**
 * Liste de services
 */
if(isset($_POST['actionServices']) && $_POST['actionServices']!="") {

    switch ($_POST['actionServices']) {

        //modification du type de pc
        case "modifyTypePcDetails" :

            //echo trim($_POST['rec_type_pc']);

            $action = (isset($_POST['action']) && $_POST['action']!="") ? $_POST['action'] : "";
            $type_pc_initial = (isset($_POST['type_pc_initial']) && $_POST['type_pc_initial']!="") ? $_POST['type_pc_initial'] : "";
            $type_pc_new = (isset($_POST['type_pc_new']) && $_POST['type_pc_new']!="") ? $_POST['type_pc_new'] : "";
            $numero_initial = (isset($_POST['numero_initial']) && $_POST['numero_initial']!="") ? $_POST['numero_initial'] : "";
            $numero = (isset($_POST['numero']) && $_POST['numero']!="") ? $_POST['numero'] : "";
            $type_pc_letter = (isset($_POST['type_pc_letter']) && $_POST['type_pc_letter']!="") ? $_POST['type_pc_letter'] : "";
            $numero_pc = $type_pc_letter.$numero;

            /*
             * - Si on est en mode modification et qu'on change le type de pc Natixis (ex: F049) ) Fixe (ex: F049),
             *   on ne teste pas si le numero 'F049' existe déjà (on aura des doublons mais l'administrateur pourra changer ensuite le numero)
             *
             * - On ne cherche le dernier numero du type de pc choisi QUE pour le mode duplication et QUE si le type a été changé de l'initial
             */
            
            //--mode modification ou duplication sans changement de type pc
            if((action != "" && action == "modify") || ($type_pc_initial!="" && $type_pc_initial==$type_pc_new)) {

                //on retourne la lettre  + le numero du modele modifié
                echo $numero_initial;

            }
            //--mode duplication avec changement de type pc
            else {
            
                //1. recuperation des infos de l'enregistrement à dupliquer
                if($type_pc_new!="" && $numero_pc!="") {

                    //si le numero de pc (lettre + chiffre) existe déjà alors on va chercher le dernier numero en y ajoutant la lettre du nouveau type de pc choisi
                    $requete = "SELECT numero FROM ordinateur WHERE numero LIKE '".$numero_initial."';";
                    $requete_prepare = $bdd->prepare($requete);
                    $requete_prepare->execute();
                    $r_numero_exist = $requete_prepare->fetchAll();

                    //numero inexistant
                    if(count($r_numero_exist) <= 0) {
                        //s'il le numero de pc n'existe pas alors on change juste la lettre et on colle le numero
                        $rec_numero = $numero_pc;
                        echo $rec_numero;
                    }
                    //numero existant
                    else {
                        //s'il le numero de pc existe dejà alors on retourne le dernier numero selon le nouveau type de pc choisi avec la lettre du nouveau type de pc
                        $requete = "SELECT numero FROM ordinateur WHERE type_pc LIKE '%".$type_pc_new."%' ORDER BY numero DESC ";

                        $requete_prepare = $bdd->prepare($requete);
                        try{ $requete_prepare->execute(); }
                        catch(PDOException $e){die($e-> getMessage()) ; }

                        //resultats
                        $requete_resultat = $requete_prepare->fetch(PDO::FETCH_ASSOC);
                        $rec_num_celad = $requete_resultat['numero'];
                        $rec_num_celad_new = substr($rec_num_celad, 1) + 1;
                        $rec_num_celad_new = $type_pc_letter . (str_pad($rec_num_celad_new, 3, "0", STR_PAD_LEFT));

                        $rec_numero = $rec_num_celad_new;
                        echo $rec_numero;
                    }

                }
            } 
            
            
        break;

        default :
            echo "-";
    }

} 
?>