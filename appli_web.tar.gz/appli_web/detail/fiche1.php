<?php
require('newPDF.php');
require('fpdf_extend.php');
$pdf=new PDF_Extend('P','mm','A4');

$pdf->SetAutoPagebreak(False);
$pdf->SetDisplayMode('real', 'single');
$pdf->AddPage();





extract($_GET);




$pdf->Image('imagepdf/banniere_celad.jpg',5,0,200);
$pdf->SetFont('Arial','B',18);
$pdf->SetTextColor(137,128,211);

$pdf->SetLineWidth(0.5);
$pdf->SetFillColor(220,237,255);
$pdf->RoundedRect(120, 40, 83, 10, 2, 'DF');

// Affichage Fiche de prêt de matériel
$pdf->SetXY(170,43);
$pdf->Cell(30,5,utf8_decode("Fiche de prêt de matériel"),0,0,'R');

//Affichage du nom
$pdf->SetXY(20,65);

$pdf->SetFont('Arial','B',14);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(25,5,utf8_decode("Nom : "),0,0,'L');

$pdf->SetFont('Arial','',14);


//Affichage du pr�nom
$pdf->SetXY(20,75);

$pdf->SetFont('Arial','B',14);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(25,5,utf8_decode("Prénom : "),0,0,'L');

$pdf->SetFont('Arial','',14);


//Affichage du client
$pdf->SetXY(20,85);

$pdf->SetFont('Arial','B',14);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(25,5,utf8_decode("Client : "),0,0,'L');

$pdf->SetFont('Arial','',14);



//Affichage de la partie contact administrateur

$pdf->SetDrawColor(200);
$pdf->SetDash(4,2); //4 mm noir, 2 mm blanc
$pdf->Rect(115, 76, 90, 20);

$pdf->SetXY(120,80);

$pdf->SetFont('Arial','B',14);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(80,5,utf8_decode("Contact Administrateurs CELAD"),0,0,'C');

$pdf->SetXY(120,87);
$pdf->SetFont('Arial','',14);
$pdf->SetTextColor(0,0,255);
$pdf->Cell(80,5,utf8_decode("informatique@celad.com"),0,0,'C');

//Affichage de la partie configuration
$pdf->SetXY(20,120);

$pdf->SetFont('Arial','B',14);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(80,5,utf8_decode("Configuration de la machine : "),0,0,'L');

$pas_x = 25;
$pas_y = 130;
$cpt = 5;
$bord = 0;


//Affichage de la partie infos supplémentaires
$y_cour = $pdf->GetY();
$pdf->SetXY(20,$y_cour+10);

$pdf->SetFont('Arial','B',14);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(80,5,utf8_decode("Informations supplémentaires : "),0,0,'L');



//Affichage des conditions de prêt
$y_cour = $pdf->GetY();
$pdf->SetXY(20,$y_cour+10);
$pdf->SetFont('Arial','B',14);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(80,5,utf8_decode("Condition du prêt : "),0,0,'L');

$y_cour = $pdf->GetY();
$pdf->SetXY(25,$y_cour+10);
$pdf->SetFont('Arial','',11);
$pdf->Cell(170,5,utf8_decode("Le collaborateur s'engage à prendre soins et à respecter le matériel de prêt."),0,0,'L');

$y_cour = $pdf->GetY();
$pdf->SetXY(25,$y_cour+$cpt);
$pdf->SetFont('Arial','',11);
$pdf->Cell(170,5,utf8_decode("En cas de dégradation, perte ou vol, il est impératif de prévenir immédiatement CELAD."),0,0,'L');


//Affichage dela signature du collaborateur
//$y_cour = $pdf->GetY();
$pdf->SetXY(130,250);
$pdf->SetFont('Arial','B',14);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(70,5,utf8_decode("Signature du collaborateur : "),0,0,'L');

$y_cour = $pdf->GetY();
$pdf->SetXY(130,$y_cour+10);
$pdf->SetFont('Arial','',12);
$pdf->Cell(70,5,utf8_decode("Fait le                             à BALMA"),0,0,'L');


//Logo Celad en bas de page
$pdf->Image('imagepdf/logo_celad.jpg',25,270,40);

$pdf->Output();

?>