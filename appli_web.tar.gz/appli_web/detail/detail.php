<script type="text/javascript">
 /*
 * fonction qui permettra de change la lettre dans le numero du pc si l'utilisateur change le type
 * @var modeAction : mode d'action en cours. Valeur possibles 'modify', 'duplicate'
 */
function changeTypePc(action, numero_initial, type_pc_initial){
    var valueTypepcLetter = "F";

    //recuperation du type sélectionné
    var valueTypepc = $('input[name="typepc"]:checked').attr("value");
    switch(valueTypepc) {
        case 'Fixe': valueTypepcLetter = "F"; break;
        case 'Portable': valueTypepcLetter = "P"; break;
        case 'Tablette': valueTypepcLetter = "P"; break;
        case 'Divers': valueTypepcLetter = "P"; break;
        case 'i-BP': valueTypepcLetter = "F"; break;
        case 'Natixis': valueTypepcLetter = "F"; break;
        default : valueTypepcLetter = "F";
    }

    //récupération de la valeur du dernier numero selon le type
    var valueNumero = $('input[name="numero"]').attr("value");
    var numero = recupChiffres(valueNumero);

    var params = "";
    params = params + 'actionServices=modifyTypePcDetails';
    params = params + '&action='+action;
    params = params + '&numero_initial='+numero_initial;
    params = params + '&numero='+numero;
    params = params + '&type_pc_initial='+type_pc_initial;
    params = params + '&type_pc_new='+valueTypepc;
    params = params + '&type_pc_letter='+valueTypepcLetter;

    var retour = envoieRequete2('../include/services.php', params);
    if (navigator.appName=='Microsoft Internet Explorer') {
        var numeroChange = retour;
    } else {
        var retour2 = retour.split(/[^\w$]+/);
        var numeroChange = retour2[1];
    }


    //modification de la lettre contenue dans le numero si le type change
    $('input[name="numero"]').attr("value", numeroChange);

}

function lookup(inputString) {
    if(inputString.length == 0) {
        // Hide the suggestion box.
        $('#suggestions').hide();
    } else {
        $.post("rpc.php", {queryString: ""+inputString+""}, function(data){
            if(data.length >0) {
                $('#suggestions').show();
                $('#autoSuggestionsList').html(data);
            }
        });
    }
} // lookup
    
function fill(thisValue) {
        $('#inputString').val(thisValue);
        setTimeout("$('#suggestions').hide();", 200);
}

</script>

<script type="text/javascript">

$('#myform').on('submit', function(e) { // Code AJAX JQUERY pour xmlHTTPRequest.
    e.preventDefault();

    var formData = new FormData($("#myform"));

    $.ajax({
        type: $this.attr('method'),
        url: $this.attr('action'),
        data: $this.serialize(),
        dataType: 'json';
    });
});
</script>

<?php
//initilisation de l'action (par defaut on est en mode modification)
$_GET['action'] = (isset($_GET['action']) && $_GET['action']!="") ? $_GET['action'] : "modify";

//Initialisation des variables
$req_idpc = 0;
$req_idsortie = 0;
$rec_num_celad = "";
$rec_marque = "";
$rec_num_serie = "";
$rec_cd_pilote = "";
$rec_ghost = "";
$rec_caracteristique = "";
$rec_date_achat = "";
$rec_magasin = "";
$rec_garantie = "";
$rec_id_ecran1 = "";
$rec_id_ecran2 = "";
$rec_id_cable = "";
$rec_id_sortie = 0;
$rec_id_ordinateur = 0;
$rec_client = "";
$rec_nom = "";
$rec_prenom = "";
$rec_date_emprunt = "";
$rec_pc_hsb = "";
$rec_type_pc = "Fixe";
$rec_ghostb = "";
$update = "";
$rec_pc_ob = "";
$rec_commentaires = "";
$rec_infos_suppl = "";
$rec_comm_retour = "";

/**
 * action duplication d'une ligne
 *
 */
if(isset($_GET['action']) && $_GET['action']=="duplicate") {
    if (isset($_GET['idpc']) && is_numeric($_GET['idpc']) && $_GET['idpc']>0 ) {

        //1. recuperation des infos de l'enregistrement à dupliquer
        $requete = "SELECT id,type_pc,numero FROM ordinateur WHERE id =".$_GET['idpc'];
        
        $requete_prepare = $bdd->prepare($requete);
        try{ $requete_prepare->execute(); }
        catch(PDOException $e){die($e-> getMessage()) ; }
        
        //resultats
        $requete_resultat = $requete_prepare->fetch(PDO::FETCH_ASSOC);
        $req_idpc = $requete_resultat['id'];
        $rec_type_pc = $requete_resultat['type_pc'];
        switch ($rec_type_pc) {
            case "Fixe":        $rec_type_pc_short = "F";   break;
            case "Portable":    $rec_type_pc_short = "P";   break;
            case "Natixis":     $rec_type_pc_short = "F";   break;
            case "i-BP":        $rec_type_pc_short = "F";   break;
            case "Tablette":    $rec_type_pc_short = "P";   break;
            case "Divers":    $rec_type_pc_short = "P";   break;
            default:            $rec_type_pc_short = "F";
        }        
        $rec_num_celad = $requete_resultat['numero'];

        
        //2. recherche du dernier numéro non utilisé selon le type de pc
        $requete = "SELECT numero FROM ordinateur WHERE type_pc LIKE '%".$rec_type_pc."%' ORDER BY numero DESC ";

        $requete_prepare = $bdd->prepare($requete);
        try{ $requete_prepare->execute(); }
        catch(PDOException $e){die($e-> getMessage()) ; }

        //resultats
        $requete_resultat = $requete_prepare->fetch(PDO::FETCH_ASSOC);
        $rec_num_celad = $requete_resultat['numero'];
        $rec_num_celad_new = substr($rec_num_celad, 1) + 1;
        $rec_num_celad_new = $rec_type_pc_short . (str_pad($rec_num_celad_new, 3, "0", STR_PAD_LEFT));
        
        //3. duplication du produit sauf l'id (qui est autoincrementé) et le numero (qui vaut le dernier numéro du type pc +1)
        $requete = "  INSERT INTO ordinateur (type_pc,numero,marque,num_serie,cd_pilote,ghost,caracteristique,id_ecran1,id_ecran2,id_cable,commentaires,infos_suppl,date_achat,magasin,garantie,pc_hs) ";
        $requete .= " SELECT type_pc,'".addslashes($rec_num_celad_new)."',marque,num_serie,cd_pilote,ghost,caracteristique,id_ecran1,id_ecran2,id_cable,'','',date_achat,magasin,garantie,pc_hs FROM ordinateur ";
        $requete .= " WHERE id =".$_GET['idpc'];

        $requete_prepare = $bdd->prepare($requete);
        $requete_prepare->execute();
        $new_id_pc = $bdd->lastInsertId();
        
        $duplicate = 1;

        //4. affichage du formulaire de modification du nouvel enregistrement créé par duplication
        //Requête de séléction de l'enregistrement récupéré
        $requete = "SELECT id,type_pc,numero,marque,num_serie,cd_pilote,ghost,caracteristique,date_achat,magasin,garantie,id_ecran1,id_ecran2,id_cable,pc_hs, commentaires,infos_suppl ";
        $requete .= "FROM ordinateur ";
        $requete .= "WHERE id =".$new_id_pc;

        $requete_prepare = $bdd->prepare($requete);
        try{$requete_prepare->execute();}
        catch(PDOException $e){ die($e-> getMessage()) ; }
        $requete_resultat = $requete_prepare->fetch(PDO::FETCH_ASSOC);

        //Affectation des valeurs dans les variables correspondantes
        $req_idpc = stripslashes($requete_resultat['id']);
        $rec_type_pc = stripslashes($requete_resultat['type_pc']);
        $rec_num_celad = stripslashes($requete_resultat['numero']);
        $rec_marque = stripslashes($requete_resultat['marque']);
        $rec_num_serie = stripslashes($requete_resultat['num_serie']);

        $rec_ghost = stripslashes($requete_resultat['ghost']);
        $rec_commentaires = stripslashes($requete_resultat['commentaires']);
        $rec_infos_suppl = stripslashes($requete_resultat['infos_suppl']);
        $rec_ghostb = "";
        if ($rec_ghost==1) {
                $rec_ghostb = "checked";
        }
        $rec_caracteristique = stripslashes($requete_resultat['caracteristique']);
        $rec_date_achat = stripslashes($requete_resultat['date_achat']);
        if (!is_null($rec_date_achat)) {
                $rec_date_achat =   date("d/m/Y", $rec_date_achat);
        }
        else {
                $rec_date_achat = "";
        }
        $rec_magasin = stripslashes($requete_resultat['magasin']);
        $rec_garantie = stripslashes($requete_resultat['garantie']);
        $rec_id_ecran1 = stripslashes($requete_resultat['id_ecran1']);
        $rec_id_ecran2 = stripslashes($requete_resultat['id_ecran2']);
        $rec_id_cable = stripslashes($requete_resultat['id_cable']);
        $rec_pc_hs = stripslashes($requete_resultat['pc_hs']);
        $rec_pc_hsb = "";
        if ($rec_pc_hs==1) {
                $rec_pc_hsb = "checked";
        }
        $update = 1;
    }
}

/**
 * action modification d'une ligne
 *
 */
if(isset($_GET['action']) && $_GET['action']=="modify") {

    //On regarde si c'est pour entrer en modification ou non
    if (isset($_GET['idpc']) && is_numeric($_GET['idpc']) && $_GET['idpc']>0 ) {
            //Requête de séléction de l'enregistrement récupéré
            $requete = "SELECT id,type_pc,numero,marque,num_serie,ghost,caracteristique,date_achat,magasin,garantie,id_ecran1,id_ecran2,id_cable,pc_hs, commentaires,infos_suppl, obsolete ";
            $requete .= "FROM ordinateur ";
            $requete .= "WHERE id =".$_GET['idpc'];

            $requete_prepare = $bdd->prepare($requete);

            try{
                    $requete_prepare->execute();
            }
            catch(PDOException $e){
                    die($e-> getMessage()) ;
            }
            $requete_resultat = $requete_prepare->fetch(PDO::FETCH_ASSOC);

            //Affectation des valeurs dans les variables correspondantes
            $req_idpc = stripslashes($requete_resultat['id']);
            $rec_type_pc = stripslashes($requete_resultat['type_pc']);
            $rec_num_celad = stripslashes($requete_resultat['numero']);
            $rec_marque = stripslashes($requete_resultat['marque']);
            $rec_num_serie = stripslashes($requete_resultat['num_serie']);
            $rec_ghost = stripslashes($requete_resultat['ghost']);
            $rec_commentaires = stripslashes($requete_resultat['commentaires']);
            $rec_infos_suppl = stripslashes($requete_resultat['infos_suppl']);
            $rec_ghostb = "";
            if ($rec_ghost==1) {
                    $rec_ghostb = "checked";
            }
            $rec_caracteristique = stripslashes($requete_resultat['caracteristique']);
            $rec_date_achat = stripslashes($requete_resultat['date_achat']);
            if (!is_null($rec_date_achat)) {
                    $rec_date_achat =   date("d/m/Y", $rec_date_achat);
            }
            else {
                    $rec_date_achat = "";
            }
            $rec_magasin = stripslashes($requete_resultat['magasin']);
            $rec_garantie = stripslashes($requete_resultat['garantie']);
            $rec_id_ecran1 = stripslashes($requete_resultat['id_ecran1']);
            $rec_id_ecran2 = stripslashes($requete_resultat['id_ecran2']);
            $rec_id_cable = stripslashes($requete_resultat['id_cable']);
            $rec_pc_hs = stripslashes($requete_resultat['pc_hs']);
            $rec_pc_ob = stripslashes($requete_resultat['obsolete']);
            $rec_pc_hsb = "";
            if ($rec_pc_hs==1) {
                    $rec_pc_hsb = "checked";
            }
            if ($rec_pc_ob==1) {
                    $rec_pc_ob = "checked";
            }
            
            $update = 1;
    }

    ?>
<?php } ?>

<div id="errors">
        <h2>Corriger les erreurs suivantes :</h2>
</div>
<form id="myform" name="myform" class="cols" method="post" action="save.php">

        <h3>Détails ou ajout d'un PC dans la base</h3>

        <fieldset>
                <legend>Infos PC</legend>
                    <label id="labelimmobile">PC hors service<input type="checkbox" class="checkbox" name="pc_hs" <?php echo $rec_pc_hsb; ?>/></label>
                    <label id="labelimmobile">PC obsolète<input type="checkbox" class="checkbox" name="pc_ob" <?php echo $rec_pc_ob; ?>/></label>
                <br /><br />
                <p style="margin-top: 30px;"><label style="margin-top: -7px;">Type de PC</label>
                        <input class="bouton" onClick="changeTypePc('<?php echo $_GET['action']; ?>','<?php echo $rec_num_celad; ?>','<?php echo $rec_type_pc; ?>');" nom_error = "Type de Pc" required="required" type="radio" name="typepc" value="Fixe" <?php echo ($rec_type_pc=="Fixe")? "checked='checked'":""; ?> />Fixe
                        <input class="bouton" onClick="changeTypePc('<?php echo $_GET['action']; ?>','<?php echo $rec_num_celad; ?>','<?php echo $rec_type_pc; ?>');" nom_error = "Type de Pc" required="required" type="radio" name="typepc" value="Portable" <?php echo ($rec_type_pc=="Portable")? "checked='checked'":""; ?> />Portable
                        <input class="bouton" onClick="changeTypePc('<?php echo $_GET['action']; ?>','<?php echo $rec_num_celad; ?>','<?php echo $rec_type_pc; ?>');" nom_error = "Type de Pc" required="required" type="radio" name="typepc" value="Natixis" <?php echo ($rec_type_pc=="Natixis")? "checked='checked'":""; ?> />Natixis
                        <input class="bouton" onClick="changeTypePc('<?php echo $_GET['action']; ?>','<?php echo $rec_num_celad; ?>','<?php echo $rec_type_pc; ?>');" nom_error = "Type de Pc" required="required" type="radio" name="typepc" value="i-BP" <?php echo ($rec_type_pc=="i-BP")? "checked='checked'":""; ?> />i-BP
                        </p>
                        <p><label></label>
                        <input class="bouton" onClick="changeTypePc('<?php echo $_GET['action']; ?>','<?php echo $rec_num_celad; ?>','<?php echo $rec_type_pc; ?>');" nom_error = "Type de Pc" required="required" type="radio" name="typepc" value="Tablette" <?php echo ($rec_type_pc=="Tablette")? "checked='checked'":""; ?> />Tablette
                        <input class="bouton" onClick="changeTypePc('<?php echo $_GET['action']; ?>','<?php echo $rec_num_celad; ?>','<?php echo $rec_type_pc; ?>');" nom_error = "Type de Pc" required="required" type="radio" name="typepc" value="Divers" <?php echo ($rec_type_pc=="Divers")? "checked='checked'":""; ?> />Divers&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*

                </p>
                <p><label>N° Celad</label><input onBlur="majuscule(this);" type="text" nom_error = "N° Celad" required="required" name="numero" value="<?php echo $rec_num_celad; ?>"/> *</p>
                <p><label>Marque / Modèle</label><input onBlur="majuscule(this);" type="text" nom_error = "Marque / Modèle" required="required" name="marque" value="<?php echo $rec_marque; ?>"/> *</p>
                <p><label>N° de série</label><input onBlur="majuscule(this);" type="text" nom_error = "N° de série" name="numserie" value="<?php echo $rec_num_serie; ?>"/></p>
                <p><label>Caractéristiques</label><input type="text" name="caracteristique" value="<?php echo $rec_caracteristique; ?>"/></p>
                <p><label>Ghost</label><input type="checkbox" class="checkbox" name="ghost" <?php echo $rec_ghostb; ?>/></p>
        </fieldset>
        <fieldset>
                <legend>Achat</legend>

                    <?php // Si on utilise Internet Explorer (Datepicker)
                    if (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== FALSE || strpos($_SERVER['HTTP_USER_AGENT'], 'Trident') !== FALSE) {
                    ?>

                    <p><label>Date d'achat</label><input type="date" name="date_achat" value="<?php echo $rec_date_achat; ?>" style="width:70px" /></p>

                    <?php  // Si on utilise Chrome
                    }else  {        // Champ Permettant d'avoir le DatePicker ne fonctionnant pas sous chrome. 
                    ?>
                    <p><label>Date d'achat</label><input type="text" value="<?php echo $rec_date_achat; ?>" disabled="disabled"  /></p>
                    <p><label>Calendrier &rarr; </label><input id="CALENDAR" type="date" name="date_achat" value="<?php echo $rec_date_achat; ?>"   /></p>
                        
                    <?php 
                    }
                    ?>

                    <p><label>Magasin</label><input onBlur="majuscule(this);" type="text" name="magasin" value="<?php echo $rec_magasin; ?>" /></p>
                    <p><label>Garantie</label>
                    <select name="garantie" style="width:130px">
                            <option value="0">Aucune garantie</option>
                            <?php
                                    for($i=1;$i < 11;$i++)
                                    {
                                        $choix = ($rec_garantie==$i)?SELECTED:"";
                                        echo '<option value="'.$i.'" '.$choix.' >'.$i.' an(s)</option>';
                                    }
                            ?>
                </select>
        </fieldset>
        <fieldset>
                <legend>Sortie</legend>
                <?php
                if ($req_idpc>0) {
                        $q_sortie  = "SELECT id, id_ordinateur, client, nom, prenom, comm_retour, date_emprunt ";
                        $q_sortie .= "FROM sortie ";
                        $q_sortie .= "WHERE id_ordinateur = ".$req_idpc." AND (date_retour IS NULL OR date_retour = 0) LIMIT 0,1";

                        $query_sortie = $bdd->prepare($q_sortie);
                        try{
                                $query_sortie->execute();
                        }
                        catch(PDOException $e){
                                die($e-> getMessage()) ;
                        }

                        if ($result = $query_sortie->fetch(PDO::FETCH_OBJ)) {
                                $rec_id_sortie = $result->id;
                                $rec_id_ordinateur = $result->id_ordinateur;
                                $rec_client = $result->client;
                                $rec_nom = $result->nom;
                                $rec_prenom = $result->prenom;
                                $rec_date_emprunt = $result->date_emprunt;
                                $rec_comm_retour = $result->comm_retour;
                                if (!is_null($rec_date_emprunt)) {
                                        $rec_date_emprunt = date("d/m/Y", $rec_date_emprunt);
                                }
                                else {
                                        $rec_date_emprunt = "";
                                }
                        }
                }
                ?>
                

                <?php // Date Picker sous IE
                if (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== FALSE ||strpos($_SERVER['HTTP_USER_AGENT'], 'Trident') !== FALSE) {
                ?>

                    <p><label>Date d'emprunt</label><input type="date" name="date_emprunt" value="<?php echo $rec_date_emprunt; ?>" style="width:70px" /></p>

                <?php  // Date Picker Sous Chrome
                }else  {
                ?>
                    <p><label>Date d'emprunt</label><input type="text" value="<?php echo $rec_date_emprunt; ?>" disabled="disabled"  /></p>
                    <p><label>Calendrier &rarr; </label><input id="CALENDAR" type="date" name="date_emprunt" value="<?php echo $rec_date_emprunt; ?>"   /></p>
                <?php 
                }
                ?>


                    <p><label>Client</label><input id="inputString" onkeyup="lookup(this.value);" onBlur="majuscule(this);fill();" type="text" name="client" value="<?php echo $rec_client; ?>" /></p>
                    <div class="suggestionsBox" id="suggestions" style="display: none;">
                            <img src="upArrow.png" style="position: relative; top: -12px; left: 30px;" alt="upArrow" />
                            <div class="suggestionList" id="autoSuggestionsList">&nbsp;
                            </div>
                    </div>
                    <p><label>Nom emprunteur</label><input onBlur="majuscule(this);" type="text" name="nom" value="<?php echo $rec_nom; ?>"/></p>
                    <p><label>Prénom emprunteur</label><input onBlur="nompropre(this);" type="text" name="prenom" value="<?php echo $rec_prenom; ?>" /></p>
        </fieldset>

        <fieldset>
                <legend>Appareils associés au Pc</legend>
                <p>
                <label>Ecran N°1</label>
                <?php
                //Selection des ecrans disponibles ou celui associé à un PC
                $condition = "";
                $q_ecran  = "SELECT DISTINCT id, num_celad, marque ";
                $q_ecran .= "FROM ecran ";
                $q_ecran .= "WHERE NOT EXISTS ";
                $q_ecran .= "(SELECT * FROM ordinateur WHERE ordinateur.id_ecran1 = ecran.id OR ordinateur.id_ecran2 = ecran.id)  ";
                $q_ecran .= "AND NOT EXISTS (SELECT * FROM sortie_ecran WHERE sortie_ecran.id_ecran = ecran.id  AND (sortie_ecran.date_retour IS NULL OR sortie_ecran.date_retour = '')) ";
                if ($update==1 && $rec_id_ecran1>0) {
                        //Condition pour avoir l'écran associé au PC
                        $condition = "OR ecran.id=".$rec_id_ecran1;
                }

                $order = " ORDER BY num_celad";
                $req_ecran = $q_ecran.$condition.$order;
                $query_ecran = $bdd->prepare($req_ecran);

                try{
                        $query_ecran->execute();
                }
                catch(PDOException $e){
                        die($e-> getMessage()) ;
                }
                $r_ecran = $query_ecran->fetchAll();

                echo '<SELECT name="ecran1">';
                echo '<option value="0">Aucun écran</option>';

                foreach($r_ecran as $ligne)
                {
                        $select_ecran1 = "";
                        if ($rec_id_ecran1 == $ligne['id']) {
                                $select_ecran1 = "SELECTED";
                        }
                        echo '<option value="'.$ligne['id'].'" '.$select_ecran1.' >'.$ligne['num_celad'].' - '.$ligne['marque'].'</option>';
                }

                echo '</SELECT>';
                ?>

                </p>

                <p><label>Ecran N°2</label>
                <?php
                $condition = "";
                if ($update==1 && $rec_id_ecran2>0) {
                        $condition = "OR ecran.id=".$rec_id_ecran2;
                }

                $order = " ORDER BY num_celad";
                $req_ecran = $q_ecran.$condition.$order;

                $query_ecran = $bdd->prepare($req_ecran);

                try {
                        $query_ecran->execute();
                }
                catch(PDOException $e){
                        die($e-> getMessage()) ;
                }
                $r_ecran = $query_ecran->fetchAll();

                echo '<SELECT name="ecran2">';
                echo '<option value="0">Aucun écran</option>';

                foreach($r_ecran as $ligne)
                {
                        $select_ecran2 = "";
                        if ($rec_id_ecran2 == $ligne['id']) {
                                $select_ecran2 = "SELECTED";
                        }
                        echo '<option value="'.$ligne['id'].'" '.$select_ecran2.' >'.$ligne['num_celad'].' - '.$ligne['marque'].'</option>';
                }

                echo '</SELECT>';
                ?>

                </p>

                <p><label>Câble de sécurité</label>
                <?php
                //Selection des câbles disponibles ou celui associé à un PC
                $condition = "";
                $q_cable  = "SELECT DISTINCT id, num_cable ";
                $q_cable .= "FROM cable ";
                $q_cable .= "WHERE NOT EXISTS ";
                $q_cable .= "(SELECT * FROM ordinateur WHERE ordinateur.id_cable = cable.id) ";

                if ($update==1 && $rec_id_cable>0) {
                        $condition = "OR cable.id =".$rec_id_cable;
                }

                $order = " ORDER BY num_cable";
                $req_cable = $q_cable.$condition.$order;

                $query_cable = $bdd->prepare($req_cable);

                try{
                        $query_cable->execute();
                }
                catch(PDOException $e){
                        die($e-> getMessage()) ;
                }
                $r_cable = $query_cable->fetchAll();

                echo '<SELECT name="cable">';
                echo '<option value="0">Aucun câble</option>';

                foreach($r_cable as $ligne)
                {
                        $select_cable = "";
                        if ($rec_id_cable == $ligne['id']) {
                                $select_cable = "SELECTED";
                        }
                        echo '<option value="'.$ligne['id'].'" '.$select_cable.' >'.$ligne['num_cable'].'</option>';
                }

                echo '</SELECT>';
                ?>

                </p>
        </fieldset>

        <p><span class="texte_seul">Commentaires</span><textarea name="commentaires" cols="40" rows="5"><?php echo $rec_commentaires; ?></textarea></p>
        <p><span class="texte_seul">Infos supplémentaires</span><textarea name="infos_suppl" cols="40" rows="5"><?php echo $rec_infos_suppl; ?></textarea></p>
        <?php if ($rec_id_sortie>0) {  ?>
                <p><span class="texte_seul">Commentaires RETOUR</span><textarea name="commentaires_retour" cols="40" rows="5"><?php echo $rec_comm_retour; ?></textarea></p>
        <?php } ?>
        <p>* : champs obligtoire</p>
        
        <div class="clear"></div>
                    
        <!-- BLOC BOUTON-->
        <div class="bloc_button">
            <!--<button type="submit" value="retourliste" name="submit" id="submit">Revenir à la liste</button>-->
            <a class="button" href="../liste/index.php?type_pc=<?php echo $rec_type_pc; ?>">Revenir à la liste</a>
            <input type="hidden" value="<?php echo $req_idpc; ?>" name="pc_id" />
            <input type="hidden" value="<?php echo $rec_id_sortie; ?>" name="id_sortie" />

            <button type="submit" value="enregistrer" name="submit" id="submit">Enregistrer les informations</button>

        <?php if ($req_idpc!=0 && $rec_date_emprunt<>"") { ?>
                <button type="submit" value="retour" name="submit" id="submit" onClick="return confirm('Confirmation du retour CELAD ?');" >Retour du PC à CELAD</button>
        <?php } ?>

        </div>
        <div class="clear"></div>

        <!-- BOUTON PDF qui affiche ou cache le lecteur onclick-->
        <button type="button" id="PDF" onclick="toggle_div(this,'idDiv');"><img src="../images/pdf.png" border="0"/><span style="font-size:10px;color:#fff;">Fiche de prêt matériel</span></button>
        <div id="idDiv" style="display:none;">
            <iframe class="link_fiche" src="fiche.php?id=<?php echo $rec_id_sortie; ?>" width="460" height="650" align="middle"></iframe>
        </div>
</form>

<script type="text/javascript">
        // Fonction permettant d'afficher / cacher une div grace a son id.
    function toggle_div(bouton, id){
        var div = document.getElementById(id);
        if (div.style.display == "none") {
            div.style.display = "block";
        }else{
            div.style.display = "none";
        }
    }
</script>

<script>
    $.tools.dateinput.localize("fr",  {
       months:        'janvier,f&eacute;vrier,mars,avril,mai,juin,juillet,ao&ucirc;t,' +
                        'septembre,octobre,novembre,d&eacute;cembre',
       shortMonths:   'jan,f&eacute;v,mar,avr,mai,jun,jul,ao&ucirc;,sep,oct,nov,d&eacute;c',
       days:          'dimanche,lundi,mardi,mercredi,jeudi,vendredi,samedi',
       shortDays:     'dim,lun,mar,mer,jeu,ven,sam'
    });

    $(":date").dateinput({
                firstDay: 1,
                format: 'dd/mm/yyyy',
                lang: 'fr'
    });

    // adds an effect called "wall" to the validator
    $.tools.validator.addEffect("wall", function(errors, event) {

        // get the message wall
        var wall = $(this.getConf().container).fadeIn();

        // remove all existing messages
        wall.find("p").remove();

        // add new ones
        $.each(errors, function(index, error) {
                wall.append(
                        "<p><strong>" +error.input.attr("nom_error")+ " : </strong> " +error.messages[0]+ "</p>"
                );
        });

    // the effect does nothing when all inputs are valid
    }, function(inputs)  {

    });

    $.tools.validator.localize("fr", {
        '*'         : 'Champs obligatoire',
        ':email'    : 'Adresse mail non valide',
        ':number'   : 'Un nombre est attendu',
        ':url'      : 'Une url est attendue',
        '[max]'     : 'Le maximum est $1',
        '[min]'     : 'Le minimum est $1',
        '[required]': 'Champs obligatoire'
    });

    // initialize validator with the new effect
    $("#myform").validator({
       effect: 'wall',
       container: '#errors',
       lang: 'fr',

       // do not validate inputs when they are edited
       errorInputEvent: null

    // custom form submission logic
    }).submit(function(e)  {

       // when data is valid
       if (!e.isDefaultPrevented()) {

          // tell user that everything is OK
          $("#errors").html("<h2>Tous les champs sont bien renseignés</h2>");

          // prevent the form data being submitted to the server
          //e.preventDefault();
       }

    });

</script>